<?php
session_start();
if($_SESSION['logged'] != 1)
{
    header('Location: http://localhost/komis/main.php');
}
else
{
    class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
    }
}

$db = new dbInfo();
$db->getDB("localhost", "root", "", "cars");
$conn = $db->dbConnect();

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ogłoszenia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        body
        {
            background-color: azure;
        }
        img
        {
            border: 3px solid black;
            border-radius: 5px;
        }
        header
        {
            font-size: 2rem;
            width: 100%; 
            background-color:azure;
            border-bottom: 1px solid gray;
            text-align: center;
        }
        a
        {
            padding: 2%;
            margin: 10px;
        }
        .card
        {
            float:left;
        }
        img
        {
            width: 1000px;
            height: 300px;
        }
        #cars
        {
            text-align: center;
            margin: auto;
            border: 1px solid black;
            width: 100%;
        }
        p
        {
            text-align: center;
        }
    </style>
</head>
<header class = "container-fluid"><a href = "main.php">Powrót</a>Ogłoszenia<a href = "add.php">Dodaj ogłoszenie</a></header>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php
    $query = $conn->prepare("SELECT `ID`, `make`, `model`, `year`, `mileage`, `price`, `image` FROM `posts`");
    $query->execute();
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    foreach($result as $row){ ?>
            <section id="cars">
            <p><b>Marka:</b> <?php echo $row['make']; ?><br>
            <b>Model:</b> <?php echo $row['model']; ?><br>
            <b>Cena:</b> <?php echo $row['price'] . ' PLN'; ?><br>
            <b>Przebieg:</b><?php echo $row['mileage']?><br>
            <b>Rocznik:</b><?php echo $row['year']?></p><br>
            <?php 
            $photosrc = $row['image'];
            $photos = array_filter(explode('/', $photosrc));
            $fileCount = count($photos);

            if (!empty($photos)) { ?>
                <div style="width:40%; margin:0 auto;" id="carousel-<?php echo $row['ID']; ?>" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <?php foreach ($photos as $index => $photo) { ?>
                            <div class="carousel-item <?php echo $index == 0 ? 'active' : ''; ?>">
                                <img src="_img/<?php echo $photo; ?>" class="d-block w-100" alt="Zdjęcie samochodu">
                            </div>
                        <?php } ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carousel-<?php echo $row['ID']; ?>" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Poprzednie</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carousel-<?php echo $row['ID']; ?>" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Następne</span>
                    </button>
                </div>
                <br><br><br><br><br><br><br>
            <?php } ?>

        </section>
                    <?php
             }
         ?>
</body>
</html>
<?php
?>