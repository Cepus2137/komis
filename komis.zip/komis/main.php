
<?php
session_start();

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        *
        {
            background-color: white;
            text-align: center;
            font-family: Verdana;
            color: rgb(40, 40, 40);  
            height: auto;
        }
        main
        {
            background-color: white;
            margin-top: 5%;
            width: 33%;
            height: 500px;
            margin-left: 33%;
            margin-bottom: 0;
            padding-top: 5%;
            text-align: center;
        }
        header
        {
            background-color: azure;
            font-size: 2rem;
            padding: 1%;
            border-bottom: 1px solid gray
        }
        a
        {
            color: black;
            padding: 25px;
            text-align: center;
            background-color: azure;
            text-decoration: none;
            border: 2px solid gray;
            border-radius: 5%;
            font-size: 2rem;
            display: block;
            width: 50%;
            margin: auto;
        }
        a:hover
        {
            background-color: azure;
            border-color: lightgray;
            transition: 1s;
            color: black;
        }
    </style>
</head>
<header>Strona główna</header>
<body>  
    <main class = "container-fluid">
    <?php
        if($_SESSION['logged'] == 1)
        {
            ?>
            <a href = "posts.php">Przeglądaj ogłoszenia</a><br>
            <a href = "users.php">Lista użytkowników</a> <br>
            <a href = "logout.php">Wyloguj się</a> 
            <?php
        }
       else
        {
            ?>
            <a href = "register.html">Zarejestruj się</a> <br>
            <a href = "login.html">Zaloguj się</a>
            <?php
        }
        ?>
    </main>
</body>
</html>
