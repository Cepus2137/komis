<?php
session_start();
class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
    }
}
$mail = $_POST['Mail'];
$password = md5($_POST['Password']);
$db = new dbInfo();
$db->getDB("localhost", "root", "", "clients");
$conn = $db->dbConnect();
//$query = mysqli_query($conn, "SELECT `mail`, `password` FROM `accounts` WHERE `mail` = '$mail' AND `password` = '$password'");
$query = $conn->prepare("SELECT `fname`, `mail`, `password` FROM `accounts` WHERE `mail` = '$mail' AND `password` = '$password'");
$query->execute();
$isFound = false;
//$query2 = mysqli_query($conn, "SELECT * FROM `accounts` WHERE `mail` = '$mail' AND `password` = '$password' AND `admin` = 'tak'");
$query2 = $conn->prepare("SELECT * FROM `accounts` WHERE `mail` = '$mail' AND `password` = '$password' AND `admin` = 'tak'");
$query2->execute();
$number_of_rows = $query->fetchColumn();
$number_of_rows2 = $query2->fetchColumn();
?>
<p>
    <?php
if($number_of_rows > 0)
{
    //$fname = $row['fname'];
    $_SESSION['logged'] = 1;
    echo"Zalogowano";
    //$_SESSION['name'] = $fname;
    if($number_of_rows2 > 0)
    {
        $_SESSION['admin'] = 1;
    }
    else
    {
        $_SESSION['admin'] = 0;
    }
    
}
    
else
    echo"Złe dane";

    ?>
    </p>
    <nav class="return"><a href = "main.php">Powrót do strony głównej</a></nav>