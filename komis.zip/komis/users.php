<?php 
session_start();
class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
    }
}
$db = new dbInfo();
$db->getDB("localhost", "root", "", "clients");
$conn = $db->dbConnect();
//$conn = mysqli_connect("localhost", "root", "", "clients");
$query = $conn->prepare("SELECT `fname`, `lname`, `mail`, `ID` FROM `accounts`;");
$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);
//$query = mysqli_query($conn, "SELECT `fname`, `lname`, `mail`, `ID` FROM `accounts`;");
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Formularz</title>
    <style>
        *
        {
            background-color: white;
            text-align: center;
            font-family: Verdana;
            color: rgb(40, 40, 40);  
            height: auto;
        }
        header
        {
            font-size: 2rem;
            width: 100%; 
            background-color:azure;
            border-bottom:1px solid gray;
        }
        a
        {
            background-color: azure;
            font-size: 1rem;
        }
        table
        {
            text-align: center;
            margin: auto;
            margin-top: 3%;
            padding: 5px;
            font-size: 20px;
            background-color: azure;
        }
        th, td
        {
            padding: 15px;
            background-color: azure;
            border: 1px solid grey;
        }
        button
        {
            padding:2px;
            margin: 5px;
        }
        form
        {
            background-color:azure;
        }
    </style>
</head>
<body>
        <table class = "table-stripped">
            <header class = "container-fluid">
                Lista użytkowników <br>
            <a href = "main.php">Powrót</a>  
            </header>
            <tr>
                <th>Imię</th><th>Nazwisko</th><th>E-mail</th><?php if(isAdmin()){ ?><th>Działanie</th> <?php }?>
            </tr>
                <?php
                foreach($results as $row)
                {
                ?>
                        <tr>
                            <td><?php echo $row['fname']; ?></td>
                            <td><?php echo $row['lname']; ?></td>
                            <td><?php echo $row['mail']; ?></td>
                            <?php
                            if(isAdmin())
                            {
                                ?>
                            <td>
                            <form action = "edit.php" method = "POST">
                                <input type = "hidden" name = "ID" value = "<?php echo $row['ID'] ?>">
                                <button type = "submit">Edytuj</button>
                            </form>
                            <form action ="users.php" method = "POST">
                                <input type = "hidden" name = "ID" value = "<?php echo $row['ID'] ?>">
                                <button type = "submit" name = "delete">Usuń</button>
                            </form>
                            </td>
                            <?php
                            }
                            ?>
                            <?php
                }
              /*     
                while($row = mysqli_fetch_array($query))
                    {
                        ?>
                        <tr>
                            <td><?php echo $row[0]; ?></td>
                            <td><?php echo $row[1]; ?></td>
                            <td><?php echo $row[2]; ?></td>
                            <?php
                            if($_SESSION['admin'] == 1)
                            {
                                ?>
                            <td>
                            <form action = "edit.php" method = "POST">
                                <input type = "hidden" name = "ID" value = "<?php echo $row[3] ?>">
                                <button type = "submit">Edytuj</button>
                            </form>
                            <form action ="users.php" method = "POST">
                                <input type = "hidden" name = "ID" value = "<?php echo $row[3] ?>">
                                <button type = "submit" name = "delete">Usuń</button>
                            </form>
                            </td>
                            <?php
                            }
                            ?>
                            <?php
                    }
                            */
                    if(isset($_POST['delete']))
                    {
                        $ID = $_POST['ID'];
                        //$query2 = mysqli_query($conn, "DELETE FROM `accounts` WHERE `ID` = '$ID'");
                        $query2 = $conn->prepare("DELETE FROM `accounts` WHERE `ID` = '$ID'");
                        $query2->execute();
                        header('Location: http://localhost/komis/users.php');
                    }
                ?>
        </table>
</body>
<?php

function isAdmin()
{
    if($_SESSION['admin'] == 1)
    {
        return true;
    }
    return false;
}
?>
</html>
