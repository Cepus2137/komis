<?php
session_start();
class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
    }
}
class imgFile
{
        function save($make, $model, $year, $mileage, $price, $image, $conn)
        {
            $query = "INSERT INTO `posts`(`make`, `model`, `year`, `mileage`, `price`, `image`) VALUES ('$make','$model','$year','$mileage','$price', '$image')";
            $result = $conn->prepare($query);
            $result->execute();
            //header('location: main.php');
        }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        *
        {
            background-color: azure;
            text-align: center;
            font-family: Verdana;
            color: rgb(40, 40, 40);  
            height: auto;
        }
        body
        {
            background-color: azure;
        }
        header
        {
            font-size: 2rem;
            border-bottom: 1px solid gray;
        }
        a
        {
            font-size: 1rem;
            background-color: azure;
        }
        form
        {
            background-color: lightgrey;
            margin-top: 5%;
            width: 33%;
            height: 500px;
            margin-left: 33%;
            margin-bottom: 0;
        }
        input
        {
            text-align: left;
            background-color: white;
            border-radius: 3%;      
        }
        button
        {
            border-radius: 10%;
            height: 40px;
            width: 80px;
            background-color: white;
        }

        button:hover
        {
            transition: 2s;
            background-color: rgb(195, 195, 195);
        }

    </style>
</head>
<body>  
    <header class = "container-fluid">
       Dodaj ogłoszenie
        <br><a href = "main.php">Powrót</a>
    </header>
    <form action = "add.php" method = "POST" enctype="multipart/form-data">
        <br><br>
        Marka: <br><input type = "text" name="make" required><br><br>
        Model: <br><input type = "text" name = "model" required><br><br>
        Rocznik: <br><input type = "text" name = "year" required><br><br>
        Przebieg: <br><input type = "text" name = "mileage" required><br><br>
        Cena: <br><input type = "text" name = "price" required><br><br>
        Zdjęcie<br><input type="file" name="image[]" multiple><br><br>
        <br><button type = "submit" name = "submit">Prześlij</button> 
    </form>
    <?php
    $db = new dbInfo();
    $db->getDB("localhost", "root", "", "cars");
    $conn = $db->dbConnect();
    if(isset($_POST['submit']))
    {
        $make = $_POST['make'];
        $model = $_POST['model'];
        $year = $_POST['year'];
        $mileage = $_POST['mileage'];
        $price = $_POST['price'];
        $car_image = "";
        if (isset($_FILES['image'])) {
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $fileCount = count($_FILES['image']['name']);
            for ($i=0; $i < $fileCount; $i++) { 

                $file_extension = strtolower(pathinfo($_FILES['image']['name'][$i], PATHINFO_EXTENSION));

                if (in_array($file_extension, $allowed_extensions)) {
                    $target = "_img/";
                    $file_name = uniqid() . "." . $file_extension;
                    $target_file = $target . $file_name;
                    if (move_uploaded_file($_FILES['image']['tmp_name'][$i], $target_file)) {
                        $car_image .= $file_name . '/'; 
                    } else {
                        echo "Błąd przy przesyłaniu zdjęcia" . $_FILES['image']['name'][$i];
                    }
                } else {
                    echo "Niedozwolone rozszerzenie pliku.";
                }
            }
        }
        $img = new imgFile();
    $img ->save($make, $model, $year, $mileage, $price, $car_image, $conn);
    }
    
    ?>
</body>
</html>
