<?php 
session_start();
class dbInfo
{
    private $host;
    private $user;
    private $password;
    private $dbname;
    public function getDB($host, $user, $password, $dbname)
    {
        $this->host = $host;
        $this->user = $user;
        $this->password = $password;
        $this->dbname = $dbname;
    }
    public function dbConnect()
    {
        try
        {
            $conn = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->user, $this->password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Połączenie udane";
            return $conn;
        }catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <style>
        *
        {
            background-color: azure;
            text-align: center;
            font-family: Verdana;
            color: rgb(40, 40, 40);  
            height: auto;
        }
        header
        {
            font-size: 2rem;
            width: 100%; 
        }
        form
        {
            background-color: lightgrey;
            margin-top: 5%;
            width: 33%;
            height: 500px;
            margin-left: 33%;
            margin-bottom: 0;
        }
        input
        {
            text-align: left;
            background-color: azure;
            border-radius: 3%;      
        }
        button
        {
            border-radius: 10%;
            height: 40px;
            width: 80px;
            background-color: azure;
        }

        button:hover
        {
            transition: 2s;
            background-color: rgb(195, 195, 195);
        }
        img
        {
            width: 10%;
            height:10%;
        }

    </style>
</head>
<body>
    <?php 
    if($_SESSION['admin'] != 1)
    {
        header('Location: http://localhost/komis/main.php');
    }
       $db = new dbInfo();
       $db->getDB("localhost", "root", "", "clients");
       $conn = $db->dbConnect();
       $ID = $_POST['ID'];
       //$conn = mysqli_connect("localhost", "root", "", "clients");
       //$query1 = mysqli_query($conn, "SELECT `fname`, `lname`, `mail`, `admin` FROM `accounts` WHERE `ID` = '$ID'");
       $query1 = $conn->prepare("SELECT `fname`, `lname`, `mail`, `admin` FROM `accounts` WHERE `ID` = '$ID'");
       $query1->execute();
       $result=$query1->fetchAll(PDO::FETCH_ASSOC);
       if(isset($query1))
       {
        foreach($result as $row)
        {
            $checkbox = '';
            $fname = $row['fname'];
            $lname = $row['lname'];
            $mail = $row['mail'];
            if($row['admin'] == 'tak')
            $checkbox = 'checked';
        }
        /*
        while($row = mysqli_fetch_array($query1))
        {
            $checkbox = '';
             $fname = $row[0];
             $lname = $row[1];
             $mail = $row[2];
             if($row[3] == 'tak')
             $checkbox = 'checked';
        }
             */
       }
    ?>
    <nav class = "return"><a href = "users.php">Powrót</a></nav>
    <form action = "edit.php" method = "POST">
        <header>Zmień dane</header>
        <br><br>
        <input type = "hidden" name = "ID" value = "<?php echo $ID ?>">
        Imię: <br><input type = "text" name="FirstName" value = "<?php echo $fname ?>"required><br><br>
        Nazwisko: <br><input type = "text" name="LastName" value = "<?php echo $lname ?>" required><br><br>
        E-mail: <br><input type = "mail" name="Mail" value = "<?php echo $mail ?>" required><br><br>
        Admin: <br><input type = "checkbox" name = "admin" <?php echo $checkbox ?>><br>
        <br><button type = "submit" name = "submit">Prześlij</button> 
    </form>
    <?php 
    if(isset($_POST['submit']) && preg_match('/[a-zA-Z]/i',$_POST['FirstName']) && preg_match('/[a-zA-Z]/i',$_POST['LastName']) && preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/',$_POST['Mail']))
    {
        $fnameUpdate = $_POST['FirstName'];
        $lnameUpdate = $_POST['LastName'];
        $mailUpdate = $_POST['Mail'];
        $ID = $_POST['ID'];
        $admin = 'nie';
        if(isset($_POST['admin']))
            $admin = 'tak';
        //$query2 = mysqli_query($conn, "UPDATE `accounts` SET `mail`='$mailUpdate', `fname`='$fnameUpdate',`lname`='$lnameUpdate', `admin` = '$admin' WHERE `ID` = '$ID'");
        $query2 = $conn->prepare("UPDATE `accounts` SET `mail`='$mailUpdate', `fname`='$fnameUpdate',`lname`='$lnameUpdate', `admin` = '$admin' WHERE `ID` = '$ID'");
        $query2->execute();
        header('Location: http://localhost/komis/users.php');
    }
    ?>

</body>
</html>
