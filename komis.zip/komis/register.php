<?php
$host = 'localhost';
$dbname = "clients";
$user = 'root';
$password = '';
try
{
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Połączenie udane";
}catch(PDOException $e)
{
    echo "Błąd połączenia: " . $e->getMessage();
}
$mail = $_POST['Mail'];
$fname = $_POST['FirstName'];
$lname = $_POST['LastName'];
$pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/';
$pattern2 = '/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/';
if(preg_match($pattern, $_POST['Password']))
{
        $password = md5($_POST['Password']);
        if(preg_match($pattern2, $mail))
        {
                //$query = mysqli_query($conn, "SELECT `mail` FROM `accounts` WHERE `mail` = '$mail'");
                $query = $conn->prepare("SELECT `mail` FROM `accounts` WHERE `mail` = '$mail'");
                $query->execute();
                $number_of_rows = $query->fetchColumn();
                if($number_of_rows == 0)
                {
                        //$query2 = mysqli_query($conn, "INSERT INTO `accounts` (`mail`, `password`, `fname`, `lname`) VALUES ('$mail', '$password', '$fname', '$lname')");
                        $query2 = $conn->prepare("INSERT INTO `accounts` (`mail`, `password`, `fname`, `lname`) VALUES ('$mail', '$password', '$fname', '$lname')");
                        $query2->execute();
                        echo "Zarejestrowano pomyślnie";
                }
                else
                {       
                echo "Podany mail znajduje się już w bazie danych";
                }
        }
        else
        {
                echo "Podany email zawiera błąd";
        }
        
}
else
{
        echo"Hasło powinno zawierać conajmniej 8 znaków, jedną wielką i małą literę oraz jedną cyfrę.";
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Wróc na stronę główną</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
        <br>
        <a href = "main.php">Powrót na stronę główną</a>
</body>
</html>